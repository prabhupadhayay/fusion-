<?php require_once 'includes/config.php' ?>
<?php require_once 'includes/header.php'; ?>

<div class="row">
	<div class="col-md-12">

		<ol class="breadcrumb">
			<li><a href="dashboard.php">Home</a></li>
			<li class="active">Customer</li>
		</ol>

		<div class="panel panel-default">
			<div class="panel-heading">
				<div class="page-heading"> <i class="glyphicon glyphicon-edit"></i> Manage Customer</div>
			</div> <!-- /panel-heading -->
			<div class="panel-body">

				<div class="remove-messages"></div>

				<div class="div-action pull pull-right" style="padding-bottom:20px;">
					<button class="btn btn-default button1" data-toggle="modal" id="addProductModalBtn" data-target="#addProductModal"> <i class="glyphicon glyphicon-plus-sign"></i> Add Customer </button>
				</div> <!-- /div-action -->

                <form class="form-inline">
  <i class="fas fa-search" aria-hidden="true"></i>
  <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
</form>

				<table class="table" id="manageCustomerTable">
					<thead>
						<tr>

							<th>Customer Name</th>

							<th>Contact</th>
							<th>Orders</th>

							<th style="width:15%;">Options</th>
						</tr>
					</thead>
					<tbody>
					<?php
					$sql="select* from customer";
					$result = $connect->query($sql);
 
 					while($row = $result ->fetch_array()){ ?>
					<tr> 

					<td><?php echo $row['customer_name'];?></td>
					<td><?php echo $row['customer_contact'];?></td>
					<td><a href="editcustomer.php?edit=<?php echo $row['id']; ?>" class="edit_btn" >Edit</a></td>
					<td><a href="deletecustomer.php?delete=<?php echo $row['id']; ?>" class="delete_btn" >Delete</a></td>
					
					

					</tr> 	
					<?php } ?>		
</tbody>
				</table>
				<!-- /table -->

			</div> <!-- /panel-body -->
		</div> <!-- /panel -->
	</div> <!-- /col-md-12 -->
</div> <!-- /row -->


<!-- add product -->
<div class="modal fade" id="addProductModal" tabindex="-1" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">

			<form class="form-horizontal" id="submitCustomerForm" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title"><i class="fa fa-plus"></i> Add Customer</h4>
				</div>

				<div class="modal-body" style="max-height:450px; overflow:auto;">

					<div id="add-customer-messages"></div>


					<div class="form-group">
						<label for="customerName" class="col-sm-3 control-label">Customer Name: </label>
						<label class="col-sm-1 control-label">: </label>
						<div class="col-sm-8">
							<input type="text" class="form-control" id="customerName" placeholder="Customer Name" name="customerName" autocomplete="off">
						</div>
					</div> <!-- /form-group-->

					<div class="form-group">
						<label for="quantity" class="col-sm-3 control-label"> Contact: </label>
						<label class="col-sm-1 control-label">: </label>
						<div class="col-sm-8">
							<input type="tel"  pattern="^\d{10}$"
       required onkeypress="return event.charCode != 45" class="form-control" id="customerContact" placeholder="Contact" name="customerContact" autocomplete="off">
	  <small>  (format: xxxxxxxxxx):ten digits only	</small>		
	</div>
					</div> <!-- /form-group-->

					<!-- <div class="form-group">
						<label for="order" class="col-sm-3 control-label">Order: </label>
						<label class="col-sm-1 control-label">: </label>
						<div class="col-sm-8">
							<input type="number" max= "100" class="form-control" id="rate" placeholder="order" name="rate" autocomplete="off">
						</div>
					</div>  -->


				</div> <!-- /form-group-->
		 

		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal"> <i class="glyphicon glyphicon-remove-sign"></i> Close</button>

			<button type="submit" class="btn btn-primary" id="createCustomerBtn" data-loading-text="Loading..." autocomplete="off"> <i class="glyphicon glyphicon-ok-sign"></i> Save Changes</button>
		</div> <!-- /modal-footer -->
		</form> <!-- /.form -->
	</div> <!-- /modal-content -->
</div> <!-- /modal-dailog -->







<?php
$valid['success'] = array('success' => false, 'messages' => array());

if ($_POST) {

	$customerName 		    = $_POST['customerName'];
	$customerContact			= $_POST['customerContact'];

	$sql = "INSERT INTO customer (customer_name,customer_contact) 
				VALUES ('$customerName',  '$customerContact')";

	if ($connect->query($sql) === TRUE) {
		$valid['success'] = true;
		$valid['messages'] = "Successfully Added";
	} else {
		$valid['success'] = false;
		$valid['messages'] = "Error while adding the members";
	}
} else {
	echo "error";
}
$connect->close();
?>
$(document).ready(function(){  
    $('#productName1').change(function(){  
      //   alert("success");
         var product_id = $(this).val();  
      //    console.log(product_id);
         $.ajax({  
              url:"fetchselectedproduct.php",  
              method:"POST",  
              data:{product_id:product_id},  
              success:function(data){  
                  // console.log(data);
                   $('#rate1').val(data); 
                    
              }  
         });  
    });  
});  


                
$(document).ready(function(){  
    $('#productName2').change(function(){  
      //   alert("success");
         var product_id = $(this).val();  
      //    console.log(product_id);
         $.ajax({  
              url:"fetchselectedproduct.php",  
              method:"POST",  
              data:{product_id:product_id},  
              success:function(data){  
                  // console.log(data);
                   $('#rate2').val(data); 
                    
              }  
         });  
    });  
});  


        
$(document).ready(function(){  
    $('#productName3').change(function(){  
      //   alert("success");
         var product_id = $(this).val();  
      //    console.log(product_id);
         $.ajax({  
              url:"fetchselectedproduct.php",  
              method:"POST",  
              data:{product_id:product_id},  
              success:function(data){  
                  // console.log(data);
                   $('#rate3').val(data); 
                    
              }  
         });  
    });  
});  

//  function getTotal(){
//     var product_id = $(this).val(); 
//   var quantity = $('#quantity1').val();
//   alert(success);
//   console.log(quantity);
//   $.ajax({
//           url:"fetchedselectedproduct.php",
//           method:"POST",
//           data:{product_id:product_id, quantity:quantity},
//           success: function(data){
//               console.log(data);
//             alert ("success");
//           }
//       })
//     }


$(document).ready(function(){  
    $('#quantity1').keyup(function(){  
        // alert("success");
    var qty=$('#quantity1').val()
     var _rate=     $('#rate1').val();
    //   console.log(_rate);
    //   console.log(qty);
      var total= qty* _rate;
    //   console.log(total);
      //    console.log(product_id);
         $('#total1').val(total);
        //  var subtotal= total;
        //  $('#totalAmount').val(subtotal);
    });  
});  

$(document).ready(function(){  
    $('#quantity2').keyup(function(){  
        // alert("success");
    var qty=$('#quantity2').val()
     var _rate=     $('#rate2').val();
    //   console.log(_rate);
    //   console.log(qty);
      var total= qty* _rate;
    //   console.log(total);
      //    console.log(product_id);
         $('#total2').val(total);
        //  var subtotal= total;
        //  $('#totalAmount').val(subtotal);
    });  
});  

$(document).ready(function(){  
    $('#quantity3').keyup(function(){  
        // alert("success");
    var qty=$('#quantity3').val()
     var _rate=     $('#rate3').val();
    //   console.log(_rate);
    //   console.log(qty);
      var total= qty* _rate;
    //   console.log(total);
      //    console.log(product_id);
         $('#total3').val(total);
        //  var subtotal= total;
        //  $('#totalAmount').val(subtotal);
    });  
});  

$(document).ready(function(){
    $('#customerName').change(function(){
        var customer_id= $(this).val();
        $.ajax({
            url:"fetchselectedCustomer.php",
            method:"post",
            data:{customer_id:customer_id},
            success:function(data){  
                // console.log(data);
                 $('#customerContact').val(data); 
                  
            }  
        })
    })
})





function fill(Value) {
    //Assigning value to "search" div in "search.php" file.
    $('#search').val(Value);
    //Hiding "display" div in "search.php" file.
    $('#display').hide();
 }
 $(document).ready(function() {
    //On pressing a key on "Search box" in "search.php" file. This function will be called.
    $("#search").keyup(function() {
        //Assigning search box value to javascript variable named as "name".
        var customer_name = $('#search').val();
        //Validating, if "name" is empty.
        if (customer_name == "") {
            //Assigning empty value to "display" div in "search.php" file.
            $("#display").html("");
        }
        //If name is not empty.
        else {
            //AJAX is called.
            $.ajax({
                //AJAX type is "Post".
                type: "POST",
                //Data will be sent to "ajax.php".
                url: "order.php",
                //Data, that will be sent to "ajax.php".
                data: {
                    //Assigning value of "name" into "search" variable.
                    search: customer_name
                },
                //If result found, this funtion will be called.
                success: function(html) {
                    //Assigning result to "display" div in "search.php" file.
                    $("#display").html(html).show();
                }
            });
        }
    });
 });
// function getDate(){
//     var today = new Date();

// document.getElementById("date").value = today.getFullYear() + '-' + ('0' + (today.getMonth() + 1)).slice(-2) + '-' + ('0' + today.getDate()).slice(-2);


// }



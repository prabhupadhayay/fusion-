<?php 	

require_once 'includes/config.php';

$product_id = $_POST['product_id'];

$sql = "SELECT * from product where id= '$product_id'";
$result = $connect->query($sql);

 
 while  ($row= mysqli_fetch_array($result)){
 echo $row['price'];
} // if num_rows

$connect->close();

// echo json_encode($row);
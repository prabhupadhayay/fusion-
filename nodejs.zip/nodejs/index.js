const express= require('express');
const bodyparser = require('body-parser')
var urlencodedParser = bodyparser.urlencoded({ extended: false });
var peopleController=require('./controller/peoplecontroller');
 var cors = require("cors");

 
const {mongoose} =require('./db.js');
 var app=express();
 app.use(bodyparser.json());
 app.use(cors({origin:'http://localhost:4200'}));
 app.listen(3000,() => console.log("Server Started at 3000"));
 app.use('/people',peopleController);
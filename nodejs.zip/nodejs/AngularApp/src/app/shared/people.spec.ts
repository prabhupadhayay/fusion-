import { People } from './people';

describe('People', () => {
  it('should create an instance', () => {
    expect(new People()).toBeTruthy();
  });
});

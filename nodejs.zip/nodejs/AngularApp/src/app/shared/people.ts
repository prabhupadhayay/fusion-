export class People {
  _id:string;
firstName: string;
lastName: string;
dob: number;
Status: number;
}

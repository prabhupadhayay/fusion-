export class Status{
  public Id:number;
  public name:string;

}

const express= require('express');
const bodyparser = require('body-parser')
var urlencodedParser = bodyparser.urlencoded({ extended: false });
var peopleController=require('./controller/peoplecontroller');
 var cors = require("cors");
 const path = require('path');



 
const {mongoose} =require('./db.js');
 var app=express();
 app.use(bodyparser.json());
 app.use(express.static(path.join(__dirname,'dist')))

 app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE");
    next();
  });
  
 app.listen(process.env.PORT || 8080);
 app.get('/',function(req,res){
     res.sendFile(path.join(__dirname+'/dist/index.html'));
 });
 console.log('console Listening at 8080');
 app.use('/people',peopleController);
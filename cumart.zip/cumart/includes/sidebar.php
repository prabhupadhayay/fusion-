<div class="row">
	<div class="col-md-2">
<div class="sidebar-wrapper">
    <div class="border-right">
      <div class="list-group list-group-flush">
        <a href="category.php" class="list-group-item list-group-item-action bg-light">Create Category</a>
        <a href="subcategory.php" class="list-group-item list-group-item-action bg-light">Sub Category</a>
        <a href="insert-product.php" class="list-group-item list-group-item-action bg-light">Insert Product </a>
        <a href="manage-products.php" class="list-group-item list-group-item-action bg-light">Manage Products</a>
      </div>
    </div>
		</div></div>
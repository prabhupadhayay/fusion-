<?php 
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>CuMart</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>
	
     <?php include('includes/header.php');?>
<div class="container">
<div class="row">
	<div class="col-md-5 text-center" style="border: 1px solid #f6f6f6; margin: 10px 20px;">
		<h4>shop with us Gents</h4>
		<hr>
		<h6>All Categories</h6> 
		<hr>
		<h6>  You will love</h6>
		<hr>
		<h6> </h6>
	</div>
		
	<div class="col-md-5 text-center" style="border: 1px solid #f6f6f6; margin: 10px 20px;">
		<h4>Shop with us ladies</h4>
		<hr>
		<h6>All Categories</h6>
		<hr>
		<h6> you will love </h6> 
		<hr>
		<h6> </h6>
	</div>
</div>
</div>
<?php 
include('includes/footer.php');
 ?>
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>

<div class="modal fade" id="edit<?php echo $urow['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<?php
		$n=mysqli_query($connect,"select * from `product` where id='".$urow['id']."'");
		$nrow=mysqli_fetch_array($n);
	?>
  <div class="modal-dialog" role="document">
    <div class="modal-content">
		<div class = "modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<center><h3 class = "text-success modal-title">Update</h3></center>
		</div>
		<form class="form-inline">
		
		
		<div class="modal-body">
		<div class="row">   
        <div class="col-md-12 form-group">
        <label for="productName" class="control-label">Product Name: </label>
		  <div class="">
                 <input type="text" value="<?php echo $nrow['product_name']; ?>" id="uproductname<?php echo $urow['id']; ?>" class="form-control">
</div>	
		
</div>

</div>


<div class="row">   
				
		<div class="col-md-12 form-group">


<label for="Quantity" class="control-label">Quantity: </label>

<div class="">
            <input type="number" value="<?php echo $nrow['quantity']; ?>" id="uquantity<?php echo $urow['id']; ?>" class="form-control"></div>
</div>

</div>

<div class="row">      
<div class="col-md-12 form-group">
<label for="price" class="control-label">Price: </label>
<div class="">
             <input type="number"   value="<?php echo $nrow['price']; ?>" id="uprice<?php echo $urow['id']; ?>" class="form-control" ></div>
        
</div>
</div>



<div class="row">
<div class="col-md-12 form-group text-left">
		<div class="modal-footer" style="text-align:left;padding:15px 0;margin-top:15px;">
			<button type="button" class="btn btn-default" data-dismiss="modal"><span class = "glyphicon glyphicon-remove"></span> Cancel</button> 
			
			<button type="button" class="updateproduct btn btn-success" value="<?php echo $urow['id']; ?>"><span class = "glyphicon glyphicon-floppy-disk"></span> Save</button>
        </div>
</div>
</div>


</div>


     </div>




		</form>
    </div>
  </div>
</div>


<style>
.modal-footer{

	text-align: :left;
}

	</style>
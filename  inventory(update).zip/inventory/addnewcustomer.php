<?php
	require_once 'includes/config.php';
	if(isset($_POST['add'])){
		$customername=$_POST['customername'];
        $customercontact=$_POST['customercontact'];
        
 
		mysqli_query($connect,"insert into `customer` (customer_name, customer_contact) values ('$customername', '$customercontact')");
	}
?>
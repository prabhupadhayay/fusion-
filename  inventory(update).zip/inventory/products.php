<?php require_once 'includes/config.php' ?>
<?php require_once 'includes/header.php'; ?>


<!DOCTYPE html>
<html lang = "en">
	<head>
	</head>
<body>

<div class="row">
	<div class="col-md-12">

		<ol class="breadcrumb">
			<li><a href="dashboard.php">Home</a></li>
			<li class="active">Product</li>
		</ol>

        <div class="panel panel-default">
			<div class="panel-heading">
				<div class="page-heading"> <i class="glyphicon glyphicon-edit"></i> Manage Product</div>
			</div> <!-- /panel-heading -->
			<div class="panel-body">
            <div class="remove-messages"></div>
		
			
				<div>
					<form class = "form-inline">
                    <div class="div-action pull pull-right" style="padding-bottom:20px; ">
						<div class = "form-group">
							<label>Product Name:</label>
							<input type  = "text" id = "productname" class = "form-control" placeholder="product name">
						</div>
						<div class = "form-group">
							<label>Price:</label>
							<input type="number" max= "1000" min="0" oninput="this.value = Math.abs(this.value)" class="form-control" id="price" placeholder="price" name="price" autocomplete="off">
                        </div>
                        <div class = "form-group">
							<label>Quantity:</label>
							<input type="number" max="100" class="form-control" id="quantity" placeholder="Quantity" name="quantity" autocomplete="off">
						</div>
						<!-- <div class = "form-group"> -->
                        <div class="div-action pull pull-right" style="padding-bottom:20px; margin-left:20px;">
							<button type = "button" id="addnew" class = "btn btn-primary" autocomplete="off" ><span class = "glyphicon glyphicon-plus"></span> Add</button>
                         </div>
                         </div> 
                        
					</form>
				</div>
                </div>
            </div><br>
			<div class="row">
            <div id="userTable"></div>
</div>
			</div>
		</div>
	</div>
</body>

<script type = "text/javascript">
	$(document).ready(function(){
		showProduct();
		//Add New
		$(document).on('click', '#addnew', function(){
			if ($('#productname').val()=="" || $('#quantity').val()=="")    {
				alert('Please input data first');
			}
			else{
			$productname=$('#productname').val();
            $price=$('#price').val();
            $quantity=$('#quantity').val();				
				$.ajax({
					type: "POST",
					url: "addnewproduct.php",
					data: {
						productname: $productname,
                        price: $price,
                        quantity:$quantity,
						add: 1,
					},
					success: function(){
						showProduct();
					}
				});
			}
		});
		//Delete
		$(document).on('click', '.delete', function(){
			$id=$(this).val();
				$.ajax({
					type: "POST",
					url: "deleteproduct.php",
					data: {
						id: $id,
						del: 1,
					},
					success: function(){
						showProduct();
					}
				});
		});
		//Update
		$(document).on('click', '.updateproduct', function(){
			$uid=$(this).val();
			$('#edit'+$uid).modal('hide');
			$('body').removeClass('modal-open');
			$('.modal-backdrop').remove();
			$uproductname=$('#uproductname'+$uid).val();
            $uprice=$('#uprice'+$uid).val();
            $uquantity=$('#uquantity'+$uid).val();
				$.ajax({
					type: "POST",
					url: "updateproduct.php",
					data: {
						id: $uid,
						productname: $uproductname,
                        price: $uprice,
                        quantity:$uquantity,
						edit: 1,
					},
					success: function(){
						showProduct();
					}
				});
		});
 
	});
 
	//Showing our Table
	function showProduct(){
		$.ajax({
			url: 'show_product.php',
			type: 'POST',
			async: false,
			data:{
				show: 1
			},
			success: function(response){
				$('#userTable').html(response);
			}
		});
	}
 

	

</script>
</html>
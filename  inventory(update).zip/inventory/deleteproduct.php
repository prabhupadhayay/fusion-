<?php require_once 'includes/config.php' ?>

<?php

	if(isset($_POST['del'])){
		$id=$_POST['id'];
		mysqli_query($connect,"delete from `product` where id='$id'");
	}
?>
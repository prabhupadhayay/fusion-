<?php
	require_once 'includes/config.php';
	if(isset($_POST['add'])){
		$productname=$_POST['productname'];
        $quantity=$_POST['quantity'];
        $price=$_POST['price'];
 
		mysqli_query($connect,"insert into `product` (product_name, quantity,price) values ('$productname', '$quantity','$price')");
	}
?>
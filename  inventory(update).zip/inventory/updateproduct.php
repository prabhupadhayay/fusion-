<?php require_once 'includes/config.php' ?>

<?php
	
	if(isset($_POST['edit'])){
		$id=$_POST['id'];
		$productname=$_POST['productname'];
        $quantity=$_POST['quantity'];
        $price=$_POST['price'];
 
		mysqli_query($connect,"update `product` set product_name='$productname', quantity='$quantity', price='$price' where id='$id'");
	}
?>
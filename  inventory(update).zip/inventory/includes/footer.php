<footer class="footer">
    <div class="row" style="margin-top: 20px;">
        <div class="col-md-3">
            <a href="index.php"><img src="" style="height: 40px; width: 100px" alt="logo"></a>
        </div>
        <div class="col-md-4">
            <p>
Copyright &copy; All rights reserved | This Project is made with <i class="fa fa-heart-o" aria-hidden="true"></i> 
                </p>
        </div>
        <div class="col-md-5">
            <ul class="list-inline">
                    <li class="list-inline-item">
                        <a href="index.php">Home</a>
                    </li>
                    <li class="list-inline-item">
                        <a href="about.php">About us</a>
                    </li>
                    <li class="list-inline-item">
                        <a href="contact.php">Contact</a>
                    </li>
                </ul>
            </div>
    </div>
</footer>
